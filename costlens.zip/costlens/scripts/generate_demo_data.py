"""Regenerate data/demo_cost_usage.csv.

    python scripts/generate_demo_data.py --days 180 --seed 42
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from costlens.data import generate_demo_data  # noqa: E402

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--days", type=int, default=180)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "data" / "demo_cost_usage.csv"))
    a = p.parse_args()
    df = generate_demo_data(days=a.days, seed=a.seed)
    df.to_csv(a.out, index=False)
    print(f"Wrote {len(df):,} rows to {a.out}")

"""Waste and inefficiency detectors.

Each detector looks at one resource's recent history and, when it finds a problem,
returns a Finding with evidence, a concrete recommendation and an estimated monthly
saving. Detectors are plain, readable rules on purpose: a finance or platform lead
must be able to check the reasoning behind every number.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np
import pandas as pd

from .analysis import detect_anomalies, window
from .data import NON_PROD_ENVS

DAYS_PER_MONTH = 30.4


@dataclass
class Thresholds:
    idle_days: int = 14
    idle_util_pct: float = 5.0
    underutil_pct: float = 25.0
    licence_peak_pct: float = 70.0
    unit_cost_increase_pct: float = 50.0
    offhours_usage_ratio: float = 0.2
    offhours_cost_ratio: float = 0.8
    storage_growth_pct: float = 15.0
    storage_usage_growth_pct: float = 5.0
    min_monthly_cost: float = 100.0


@dataclass
class Finding:
    kind: str
    title: str
    resource_id: str
    resource_name: str
    service: str
    team: str
    environment: str
    monthly_cost: float
    est_monthly_savings: float
    confidence: str
    evidence: str
    recommendation: str
    severity: str = field(default="low")

    def __post_init__(self):
        s = self.est_monthly_savings
        self.severity = "high" if s >= 2000 else "medium" if s >= 500 else "low"


KIND_LABELS = {
    "idle": "Idle resource",
    "underutilized": "Over-provisioned",
    "unit_cost_regression": "Cost per unit jumped",
    "off_hours": "Non-prod running 24/7",
    "cold_storage": "Cold data on hot storage",
    "unused_licences": "Unused licences",
    "cost_spike": "Cost spike",
    "untagged": "No owner tag",
}


def _monthly(cost_series: pd.Series, days: int) -> float:
    return float(cost_series.sum() / days * DAYS_PER_MONTH)


def _meta(g: pd.DataFrame) -> dict:
    last = g.iloc[-1]
    return dict(resource_id=str(last["resource_id"]), resource_name=str(last["resource_name"]),
                service=str(last["service"]), team=str(last["team"]), environment=str(last["environment"]))


def singular(unit: str) -> str:
    unit = unit.strip()
    if unit.endswith("ies"):
        return unit[:-3] + "y"
    return unit[:-1] if unit.endswith("s") and not unit.endswith("ss") else unit


def _fmt_money(x: float) -> str:
    return f"${x:,.0f}"


# ---------------------------------------------------------------------------
# Individual detectors
# ---------------------------------------------------------------------------

def check_idle(g: pd.DataFrame, th: Thresholds) -> Finding | None:
    recent = g.tail(th.idle_days)
    cost = recent["cost_usd"].sum()
    if cost <= 0:
        return None
    monthly = _monthly(recent["cost_usd"], len(recent))
    if monthly < th.min_monthly_cost:
        return None
    has_usage = recent["usage_units"].notna().any()
    has_util = recent["utilization_pct"].notna().any()
    no_usage = has_usage and recent["usage_units"].fillna(0).sum() == 0
    low_util = has_util and recent["utilization_pct"].mean() < th.idle_util_pct
    if not (no_usage and (low_util or not has_util)):
        return None

    # How long has it been idle?
    used = g[g["usage_units"].fillna(0) > 0]
    idle_since = used["date"].max() + pd.Timedelta(days=1) if len(used) else g["date"].min()
    idle_days = int((g["date"].max() - idle_since).days + 1)
    idle_cost = g[g["date"] >= idle_since]["cost_usd"].sum()
    since_txt = (f"since {idle_since.date().isoformat()} ({idle_days} days)" if len(used)
                 else f"for the whole {idle_days}-day history")
    unit = g["usage_unit_name"].iloc[-1]
    category = g["category"].iloc[-1]
    action = ("Delete it or move it to an archive tier after confirming with the owner; "
              "set a lifecycle rule so it cannot grow again."
              if category == "storage" else
              "Stop or terminate it after confirming with the owner. Snapshot first if the disk "
              "holds anything needed; add an auto-stop policy for idle instances.")
    util_txt = f", average utilisation {recent['utilization_pct'].mean():.1f}%" if has_util else ""
    return Finding(
        kind="idle",
        title=f"{g['resource_name'].iloc[-1]} has had zero {unit} {since_txt}",
        **_meta(g),
        monthly_cost=monthly,
        est_monthly_savings=monthly * 0.95,
        confidence="high",
        evidence=(f"0 {unit} {since_txt}{util_txt}. It still costs {_fmt_money(monthly)}/month "
                  f"and has cost {_fmt_money(idle_cost)} while idle."),
        recommendation=action,
    )


def _baseline_offset(g: pd.DataFrame) -> int:
    """Compare against the 30 days ending 90 days ago when history allows (catches
    changes made up to ~3 months ago), otherwise the 30 days ending 60 days ago."""
    span = (g["date"].max() - g["date"].min()).days + 1
    return 90 if span >= 120 else 60


def check_unit_cost_regression(g: pd.DataFrame, th: Thresholds) -> Finding | None:
    if g["category"].iloc[-1] == "storage":
        return None  # storage cost follows volume stored, not reads; see check_cold_storage
    now = window(g, 30)
    off = _baseline_offset(g)
    then = window(g, 30, offset=off)
    if len(then) < 20 or now["usage_units"].isna().all():
        return None
    u_now, u_then = now["usage_units"].sum(), then["usage_units"].sum()
    c_now, c_then = now["cost_usd"].sum(), then["cost_usd"].sum()
    if u_now <= 0 or u_then <= 0 or c_then <= 0:
        return None
    uc_now, uc_then = c_now / u_now, c_then / u_then
    rise = (uc_now / uc_then - 1) * 100
    if rise < th.unit_cost_increase_pct:
        return None
    monthly = c_now / len(now) * DAYS_PER_MONTH
    if monthly < th.min_monthly_cost:
        return None
    excess = (c_now - u_now * uc_then) / len(now) * DAYS_PER_MONTH
    usage_g = (u_now / u_then - 1) * 100
    cost_g = (c_now / c_then - 1) * 100

    # When did it change? Find the first week the 7-day unit cost crossed halfway.
    s = g.set_index("date")
    roll = (s["cost_usd"].rolling(7).sum() / s["usage_units"].rolling(7).sum()).dropna()
    mid = uc_then + (uc_now - uc_then) / 2
    crossed = roll[roll > mid]
    when = f" The change started around {crossed.index[0].date().isoformat()}." if len(crossed) else ""

    util_txt = ""
    if g["utilization_pct"].notna().any():
        util_txt = (f" Utilisation went from {then['utilization_pct'].mean():.0f}% to "
                    f"{now['utilization_pct'].mean():.0f}%.")
    unit = g["usage_unit_name"].iloc[-1]
    rec = ("Usage did not grow with the cost, so capacity was added that work does not need. "
           "Size it back down (or enable auto-suspend / autoscaling) and re-check query "
           "performance for a week.")
    return Finding(
        kind="unit_cost_regression",
        title=f"{g['resource_name'].iloc[-1]}: cost per {singular(unit)} up {rise:.0f}%",
        **_meta(g),
        monthly_cost=monthly,
        est_monthly_savings=max(excess, 0) * 0.85,
        confidence="high" if usage_g < 10 else "medium",
        evidence=(f"Cost changed {cost_g:+.0f}% while {unit} changed {usage_g:+.0f}% "
                  f"(last 30 days vs {off}-{off + 30} days ago). Cost per {singular(unit)} went from "
                  f"${uc_then:.4f} to ${uc_now:.4f}.{when}{util_txt}"),
        recommendation=rec,
    )


def check_off_hours(g: pd.DataFrame, th: Thresholds) -> Finding | None:
    env = str(g["environment"].iloc[-1]).lower()
    if env not in NON_PROD_ENVS:
        return None
    recent = window(g, 28)
    wd = recent[recent["date"].dt.weekday < 5]
    we = recent[recent["date"].dt.weekday >= 5]
    if len(wd) < 10 or len(we) < 4:
        return None
    wd_cost, we_cost = wd["cost_usd"].mean(), we["cost_usd"].mean()
    if wd_cost <= 0 or we_cost / wd_cost < th.offhours_cost_ratio:
        return None
    signal = "usage_units" if wd["usage_units"].notna().any() else "utilization_pct"
    if wd[signal].isna().all():
        return None
    wd_u, we_u = wd[signal].mean(), we[signal].mean()
    if wd_u <= 0 or we_u / wd_u > th.offhours_usage_ratio:
        return None
    monthly = _monthly(recent["cost_usd"], len(recent))
    if monthly < th.min_monthly_cost:
        return None
    # Stopping weekends (2/7) and nights 20:00-08:00 on weekdays (5/7 * 12/24).
    saving_share = 2 / 7 + (5 / 7) * (12 / 24)
    label = g["usage_unit_name"].iloc[-1] if signal == "usage_units" else "utilisation"
    return Finding(
        kind="off_hours",
        title=f"{g['resource_name'].iloc[-1]} ({env}) runs all week but is used on weekdays only",
        **_meta(g),
        monthly_cost=monthly,
        est_monthly_savings=monthly * saving_share * 0.9,
        confidence="medium",
        evidence=(f"Weekend cost is {we_cost / wd_cost * 100:.0f}% of weekday cost, but weekend "
                  f"usage ({label}) is only {we_u / wd_u * 100:.0f}% of weekdays (last 4 weeks)."),
        recommendation=("Put it on a schedule: stop at 20:00 and at weekends, start at 08:00 on "
                        "weekdays (instance scheduler, cluster auto-termination, or a cron job)."),
    )


def check_underutilized(g: pd.DataFrame, th: Thresholds) -> Finding | None:
    cat = g["category"].iloc[-1]
    if cat not in {"compute", "warehouse", "database", "saas"}:
        return None
    recent = g.tail(14)
    if recent["utilization_pct"].isna().all():
        return None
    util = recent["utilization_pct"].mean()
    monthly = _monthly(recent["cost_usd"], len(recent))
    if monthly < th.min_monthly_cost:
        return None
    name = g["resource_name"].iloc[-1]
    if cat == "saas":
        # Seats are bought for busy days, so judge licences on busy-day (p90) use.
        peak = recent["utilization_pct"].quantile(0.9)
        if peak >= th.licence_peak_pct:
            return None
        keep = min(1.0, peak / 100 * 1.15)  # keep 15% headroom over busy days
        return Finding(
            kind="unused_licences",
            title=f"{name}: only {peak:.0f}% of paid seats are used on busy days",
            **_meta(g),
            monthly_cost=monthly,
            est_monthly_savings=monthly * (1 - keep),
            confidence="medium",
            evidence=(f"Average seat use {util:.0f}%, busy-day (p90) use {peak:.0f}% over the last "
                      "14 days."),
            recommendation=("Reclaim seats from users inactive for 30+ days and reduce the seat "
                            "count at renewal, keeping ~15% headroom."),
        )
    if util >= th.underutil_pct:
        return None
    p95 = recent["utilization_pct"].quantile(0.95)
    # Halve the size if even peak load fits comfortably in half the capacity.
    cut = 0.5 if p95 < 40 else 0.25
    return Finding(
        kind="underutilized",
        title=f"{name} averages {util:.0f}% utilisation",
        **_meta(g),
        monthly_cost=monthly,
        est_monthly_savings=monthly * cut * 0.9,
        confidence="medium" if p95 < 40 else "low",
        evidence=f"Average utilisation {util:.1f}%, p95 {p95:.1f}% over the last 14 days.",
        recommendation=(f"Right-size to roughly {int((1 - cut) * 100)}% of current capacity "
                        "(next smaller instance or warehouse size) and watch p95 load for a week."),
    )


def check_cold_storage(g: pd.DataFrame, th: Thresholds) -> Finding | None:
    if g["category"].iloc[-1] != "storage":
        return None
    now = window(g, 30)
    then = window(g, 30, offset=60)
    if len(then) < 20:
        return None
    c_now, c_then = now["cost_usd"].sum(), then["cost_usd"].sum()
    if c_then <= 0:
        return None
    cost_g = (c_now / c_then - 1) * 100
    u_now, u_then = now["usage_units"].sum(), then["usage_units"].sum()
    if u_then <= 0:
        return None  # zero-read buckets are handled by the idle check
    usage_g = (u_now / u_then - 1) * 100
    if cost_g < th.storage_growth_pct or usage_g > th.storage_usage_growth_pct:
        return None
    monthly = c_now / len(now) * DAYS_PER_MONTH
    if monthly < th.min_monthly_cost:
        return None
    unit = g["usage_unit_name"].iloc[-1]
    return Finding(
        kind="cold_storage",
        title=f"{g['resource_name'].iloc[-1]} keeps growing but is not read more",
        **_meta(g),
        monthly_cost=monthly,
        est_monthly_savings=monthly * 0.45,
        confidence="medium",
        evidence=(f"Storage cost {cost_g:+.0f}% while {unit} {usage_g:+.0f}% (last 30 days vs "
                  "60-90 days ago). Most new data is written once and rarely read."),
        recommendation=("Add a lifecycle rule: move objects older than 30 days to an infrequent-"
                        "access tier and older than 180 days to archive; expire temporary files."),
    )


def check_untagged(g: pd.DataFrame, th: Thresholds) -> Finding | None:
    if g["team"].iloc[-1] != "Untagged":
        return None
    recent = window(g, 30)
    monthly = _monthly(recent["cost_usd"], max(len(recent), 1))
    if monthly < th.min_monthly_cost:
        return None
    return Finding(
        kind="untagged",
        title=f"{g['resource_name'].iloc[-1]} has no owner",
        **_meta(g),
        monthly_cost=monthly,
        est_monthly_savings=0.0,
        confidence="high",
        evidence=f"{_fmt_money(monthly)}/month with no team tag, so nobody is accountable for it.",
        recommendation=("Find the owner from access logs or the creator, add a team tag, and "
                        "enforce tagging at creation time (tag policy / IaC check)."),
    )


DETECTORS = [check_idle, check_unit_cost_regression, check_off_hours, check_underutilized,
             check_cold_storage, check_untagged]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

FINDING_COLUMNS = ["kind", "label", "severity", "title", "resource_id", "resource_name", "service",
                   "team", "environment", "monthly_cost", "est_monthly_savings", "confidence",
                   "evidence", "recommendation"]


def run_detectors(df: pd.DataFrame, th: Thresholds | None = None,
                  anomalies: pd.DataFrame | None = None) -> pd.DataFrame:
    th = th or Thresholds()
    findings: list[Finding] = []
    for _, g in df.sort_values("date").groupby("resource_id"):
        g = g.reset_index(drop=True)
        got: dict[str, Finding] = {}
        for det in DETECTORS:
            f = det(g, th)
            if f:
                got[f.kind] = f
        # Avoid double counting savings on one resource: idle wins over everything;
        # unit-cost regression wins over plain under-utilisation.
        if "idle" in got:
            for k in ("underutilized", "off_hours", "unit_cost_regression", "cold_storage"):
                got.pop(k, None)
        if "unit_cost_regression" in got:
            got.pop("underutilized", None)
        if "off_hours" in got and "underutilized" in got:
            got["underutilized"].est_monthly_savings *= 0.4
            got["underutilized"].__post_init__()
        findings.extend(got.values())

    anomalies = detect_anomalies(df) if anomalies is None else anomalies
    for rid, a in anomalies.groupby("resource_id"):
        total = a["excess_usd"].sum()
        days = ", ".join(sorted(d.date().isoformat() for d in a["date"]))
        g = df[df["resource_id"] == rid].sort_values("date")
        f = Finding(
            kind="cost_spike",
            title=f"{a['resource_name'].iloc[0]} spiked {_fmt_money(total)} above normal",
            **_meta(g),
            monthly_cost=_monthly(window(g, 30)["cost_usd"], 30),
            est_monthly_savings=0.0,
            confidence="high",
            evidence=(f"{len(a)} anomalous day(s): {days}. Peak day "
                      f"{_fmt_money(a['cost_usd'].max())} vs a normal "
                      f"{_fmt_money(a['expected_usd'].median())}."),
            recommendation=("Check the job runs on those days for retries, a missing filter or a "
                            "changed cluster config; add a per-job cost budget alert so the next "
                            "runaway is stopped within hours."),
        )
        # Spend already lost; report it so the team can claim credits or fix the cause.
        f.est_monthly_savings = 0.0
        f.severity = "high" if total >= 1000 else "medium" if total >= 300 else "low"
        findings.append(f)

    if not findings:
        return pd.DataFrame(columns=FINDING_COLUMNS)
    out = pd.DataFrame([asdict(f) for f in findings])
    out["label"] = out["kind"].map(KIND_LABELS)
    sev_rank = out["severity"].map({"high": 0, "medium": 1, "low": 2})
    out = out.assign(_r=sev_rank).sort_values(["_r", "est_monthly_savings"], ascending=[True, False])
    return out.drop(columns="_r")[FINDING_COLUMNS].reset_index(drop=True)

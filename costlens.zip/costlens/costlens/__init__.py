"""CostLens: find out why platform cost grows faster than usage, and what to do about it."""

__version__ = "1.0.0"

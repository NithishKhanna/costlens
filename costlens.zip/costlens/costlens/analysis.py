"""Portfolio-level analysis: KPIs, cost-vs-usage gap, team view, anomalies, forecast."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


def window(df: pd.DataFrame, days: int, offset: int = 0) -> pd.DataFrame:
    """Rows in the `days`-long window ending `offset` days before the last date."""
    end = df["date"].max() - pd.Timedelta(days=offset)
    start = end - pd.Timedelta(days=days - 1)
    return df[(df["date"] >= start) & (df["date"] <= end)]


def pct_change(new: float, old: float) -> float:
    if old == 0 or np.isnan(old):
        return np.nan
    return (new - old) / abs(old) * 100.0


# ---------------------------------------------------------------------------
# Cost vs usage index
# ---------------------------------------------------------------------------

def cost_usage_index(df: pd.DataFrame, freq: str = "W-SUN", baseline_periods: int = 4) -> pd.DataFrame:
    """Weekly cost index vs a cost-weighted usage index, both 100 at the baseline.

    Usage units differ per resource (queries, task runs, reads...), so each resource's
    usage is indexed to its own baseline and the indices are blended using each
    resource's share of baseline cost. The result answers: "if usage had driven cost,
    where would cost be now?"
    """
    d = df.copy()
    d["period"] = d["date"].dt.to_period(freq).dt.start_time
    per = d.groupby(["period", "resource_id"]).agg(cost=("cost_usd", "sum"), usage=("usage_units", "sum"),
                                                   has_usage=("usage_units", "count")).reset_index()
    periods = sorted(per["period"].unique())
    # Drop partial first/last weeks so the index is not distorted.
    counts = d.groupby("period")["date"].nunique()
    full = [p for p in periods if counts.get(p, 0) >= 7]
    if len(full) < baseline_periods + 1:
        full = periods
    per = per[per["period"].isin(full)]
    base_p = full[:baseline_periods]

    base = per[per["period"].isin(base_p)].groupby("resource_id").agg(
        base_cost=("cost", "mean"), base_usage=("usage", "mean"), base_has=("has_usage", "sum"))
    usage_res = base[(base["base_has"] > 0) & (base["base_usage"] > 0)]
    weights = usage_res["base_cost"] / usage_res["base_cost"].sum() if len(usage_res) else pd.Series(dtype=float)

    total_cost = per.groupby("period")["cost"].sum()
    base_total = total_cost.loc[base_p].mean()

    u = per[per["resource_id"].isin(weights.index)].copy()
    u = u.join(usage_res[["base_usage"]], on="resource_id")
    u["idx"] = u["usage"] / u["base_usage"]
    u["w"] = u["resource_id"].map(weights)
    usage_idx = (u["idx"] * u["w"]).groupby(u["period"]).sum() * 100

    out = pd.DataFrame({
        "period": total_cost.index,
        "cost": total_cost.values,
        "cost_index": (total_cost / base_total * 100).values,
    })
    out["usage_index"] = out["period"].map(usage_idx).astype(float)
    out["gap"] = out["cost_index"] - out["usage_index"]
    return out.reset_index(drop=True)


# ---------------------------------------------------------------------------
# KPIs
# ---------------------------------------------------------------------------

@dataclass
class KPIs:
    days_of_data: int
    start: pd.Timestamp
    end: pd.Timestamp
    cost_30d: float
    cost_prev_30d: float
    cost_growth_pct: float
    usage_growth_pct: float
    cost_index_now: float
    usage_index_now: float
    annual_run_rate: float
    untagged_cost_30d: float
    untagged_share_pct: float
    n_resources: int
    n_teams: int

    def as_dict(self) -> dict:
        d = self.__dict__.copy()
        d["start"] = self.start.date().isoformat()
        d["end"] = self.end.date().isoformat()
        return d


def compute_kpis(df: pd.DataFrame) -> KPIs:
    last = window(df, 30)
    prev = window(df, 30, offset=30)
    c30, cp = last["cost_usd"].sum(), prev["cost_usd"].sum()

    # Usage growth over the same windows, cost-weighted across resources.
    ug = _weighted_usage_growth(last, prev)
    idx = cost_usage_index(df)
    tail = idx.dropna(subset=["usage_index"]).tail(2)
    cost_now = float(tail["cost_index"].mean()) if len(tail) else np.nan
    usage_now = float(tail["usage_index"].mean()) if len(tail) else np.nan

    untagged = last.loc[last["team"] == "Untagged", "cost_usd"].sum()
    return KPIs(
        days_of_data=int((df["date"].max() - df["date"].min()).days + 1),
        start=df["date"].min(),
        end=df["date"].max(),
        cost_30d=float(c30),
        cost_prev_30d=float(cp),
        cost_growth_pct=float(pct_change(c30, cp)),
        usage_growth_pct=float(ug),
        cost_index_now=cost_now,
        usage_index_now=usage_now,
        annual_run_rate=float(c30 / 30 * 365),
        untagged_cost_30d=float(untagged),
        untagged_share_pct=float(untagged / c30 * 100) if c30 else 0.0,
        n_resources=int(df["resource_id"].nunique()),
        n_teams=int(df.loc[df["team"] != "Untagged", "team"].nunique()),
    )


def _weighted_usage_growth(last: pd.DataFrame, prev: pd.DataFrame) -> float:
    a = last.groupby("resource_id").agg(u=("usage_units", "sum"), c=("cost_usd", "sum"))
    b = prev.groupby("resource_id").agg(u=("usage_units", "sum"), c=("cost_usd", "sum"))
    j = a.join(b, lsuffix="_now", rsuffix="_prev", how="inner")
    j = j[(j["u_prev"] > 0)]
    if j.empty:
        return np.nan
    growth = j["u_now"] / j["u_prev"] - 1
    return float(np.average(growth, weights=j["c_prev"]) * 100)


# ---------------------------------------------------------------------------
# Per-resource and per-team summaries
# ---------------------------------------------------------------------------

def resource_summary(df: pd.DataFrame) -> pd.DataFrame:
    last = window(df, 30)
    prev = window(df, 30, offset=30)
    meta = df.sort_values("date").groupby("resource_id")[
        ["resource_name", "service", "category", "team", "environment", "usage_unit_name"]].last()
    a = last.groupby("resource_id").agg(cost_30d=("cost_usd", "sum"), usage_30d=("usage_units", "sum"),
                                        util_30d=("utilization_pct", "mean"))
    b = prev.groupby("resource_id").agg(cost_prev=("cost_usd", "sum"), usage_prev=("usage_units", "sum"))
    out = meta.join(a).join(b).fillna({"cost_30d": 0, "cost_prev": 0})
    out["cost_growth_pct"] = [pct_change(n, o) for n, o in zip(out["cost_30d"], out["cost_prev"])]
    out["usage_growth_pct"] = [pct_change(n, o) for n, o in zip(out["usage_30d"], out["usage_prev"])]
    out["unit_cost_30d"] = np.where(out["usage_30d"] > 0, out["cost_30d"] / out["usage_30d"], np.nan)
    return out.sort_values("cost_30d", ascending=False).reset_index()


def team_summary(df: pd.DataFrame, findings: pd.DataFrame | None = None) -> pd.DataFrame:
    last = window(df, 30)
    prev = window(df, 30, offset=30)
    a = last.groupby("team")["cost_usd"].sum().rename("cost_30d")
    b = prev.groupby("team")["cost_usd"].sum().rename("cost_prev_30d")
    out = pd.concat([a, b], axis=1).fillna(0)
    out["cost_growth_pct"] = [pct_change(n, o) for n, o in zip(out["cost_30d"], out["cost_prev_30d"])]
    out["usage_growth_pct"] = [
        _weighted_usage_growth(last[last["team"] == t], prev[prev["team"] == t]) for t in out.index
    ]
    out["share_pct"] = out["cost_30d"] / out["cost_30d"].sum() * 100
    if findings is not None and len(findings):
        sav = findings.groupby("team")["est_monthly_savings"].sum()
        out["savings_available"] = out.index.map(sav).fillna(0)
    else:
        out["savings_available"] = 0.0
    out.index.name = "team"
    return out.sort_values("cost_30d", ascending=False).reset_index()


# ---------------------------------------------------------------------------
# Anomalies
# ---------------------------------------------------------------------------

def detect_anomalies(df: pd.DataFrame, z_threshold: float = 6.0, min_excess_usd: float = 150.0,
                     lookback: int = 28) -> pd.DataFrame:
    """Daily cost spikes per resource using a robust (median/MAD) rolling baseline.

    A day is anomalous when it is far above the resource's recent normal AND the
    excess is large enough in dollars to matter. Weekday/weekend patterns are
    handled by comparing each day with the same weekday type.
    """
    rows = []
    for rid, g in df.sort_values("date").groupby("resource_id"):
        s = g.set_index("date")["cost_usd"]
        is_wd = s.index.weekday < 5
        for mask in (is_wd, ~is_wd):
            sub = s[mask]
            if len(sub) < 10:
                continue
            med = sub.shift(1).rolling(lookback // 2, min_periods=6).median()
            mad = (sub.shift(1) - med).abs().rolling(lookback // 2, min_periods=6).median()
            scale = (1.4826 * mad).clip(lower=sub.shift(1).rolling(lookback // 2, min_periods=6).median() * 0.05)
            z = (sub - med) / scale.replace(0, np.nan)
            excess = sub - med
            hit = (z > z_threshold) & (excess > min_excess_usd)
            for d in sub.index[hit.fillna(False)]:
                # Skip level shifts (e.g. a permanent resize): if cost stays high for the
                # following week it is a new normal, handled by the unit-cost check.
                after = s[(s.index > d) & (s.index <= d + pd.Timedelta(days=10))]
                if len(after) >= 5 and after.median() > med[d] + 0.5 * excess[d]:
                    continue
                rows.append({
                    "date": d,
                    "resource_id": rid,
                    "resource_name": g["resource_name"].iloc[-1],
                    "team": g["team"].iloc[-1],
                    "service": g["service"].iloc[-1],
                    "cost_usd": float(sub[d]),
                    "expected_usd": float(med[d]),
                    "excess_usd": float(excess[d]),
                    "z_score": float(z[d]),
                })
    out = pd.DataFrame(rows, columns=["date", "resource_id", "resource_name", "team", "service",
                                      "cost_usd", "expected_usd", "excess_usd", "z_score"])
    return out.sort_values("date", ascending=False).reset_index(drop=True)


# ---------------------------------------------------------------------------
# Forecast
# ---------------------------------------------------------------------------

def forecast(df: pd.DataFrame, horizon_days: int = 90, fit_days: int = 60,
             monthly_savings: float = 0.0) -> pd.DataFrame:
    """Simple, explainable forecast: linear trend on the last `fit_days` of daily cost,
    with a weekday/weekend profile. Also returns a 'with fixes' line that removes the
    recommended savings ramped in over 30 days."""
    daily = df.groupby("date")["cost_usd"].sum().asfreq("D", fill_value=0)
    hist = daily.iloc[-fit_days:]
    x = np.arange(len(hist))
    wk = (hist.index.weekday < 5).astype(float)
    # cost = a + b*t + c*is_weekday
    X = np.column_stack([np.ones_like(x), x, wk])
    coef, *_ = np.linalg.lstsq(X, hist.values, rcond=None)
    resid_sd = float(np.std(hist.values - X @ coef))

    fut_idx = pd.date_range(daily.index[-1] + pd.Timedelta(days=1), periods=horizon_days, freq="D")
    xf = np.arange(len(hist), len(hist) + horizon_days)
    wkf = (fut_idx.weekday < 5).astype(float)
    pred = coef[0] + coef[1] * xf + coef[2] * wkf
    ramp = np.clip(np.arange(1, horizon_days + 1) / 30, 0, 1)
    with_fixes = pred - ramp * (monthly_savings / 30.4)

    hist_df = pd.DataFrame({"date": daily.index, "actual": daily.values})
    fut_df = pd.DataFrame({
        "date": fut_idx,
        "forecast": pred,
        "low": pred - 1.64 * resid_sd,
        "high": pred + 1.64 * resid_sd,
        "with_fixes": with_fixes,
    })
    return pd.concat([hist_df, fut_df], ignore_index=True)

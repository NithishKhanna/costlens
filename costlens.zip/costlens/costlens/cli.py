"""Command-line entry point for scheduled runs (cron, Airflow, GitHub Actions).

Examples
    python -m costlens.cli --demo --out reports/
    python -m costlens.cli --input billing_export.csv --out reports/ --fail-above 5000
    python -m costlens.cli --input billing.csv --slack-webhook "$SLACK_WEBHOOK_URL"
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request
from pathlib import Path

from .data import DataValidationError, generate_demo_data, load_csv, prepare
from .narrator import executive_summary
from .pipeline import analyse
from .report import slack_text, to_json, to_markdown


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="costlens", description="Find platform cost growing faster than usage.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--input", help="CSV with one row per resource per day")
    src.add_argument("--demo", action="store_true", help="use the built-in demo dataset")
    p.add_argument("--out", default="reports", help="folder for report.md, findings.csv, snapshot.json")
    p.add_argument("--no-llm", action="store_true", help="never call the Claude API")
    p.add_argument("--slack-webhook", default=os.getenv("SLACK_WEBHOOK_URL"),
                   help="post a short summary to this Slack incoming webhook")
    p.add_argument("--fail-above", type=float, default=None,
                   help="exit with code 2 if identified monthly savings exceed this many dollars")
    args = p.parse_args(argv)

    try:
        if args.demo:
            result = prepare(generate_demo_data())
        else:
            result = load_csv(args.input)
    except (DataValidationError, FileNotFoundError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    for w in result.warnings:
        print(f"warning: {w}", file=sys.stderr)

    a = analyse(result.df)
    summary, source = executive_summary(a.context, use_llm=not args.no_llm)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "report.md").write_text(to_markdown(a, summary), encoding="utf-8")
    a.findings.to_csv(out / "findings.csv", index=False)
    (out / "snapshot.json").write_text(to_json(a), encoding="utf-8")

    print(f"CostLens: {len(a.findings)} findings, ${a.monthly_savings:,.0f}/month savings "
          f"(summary: {source}). Reports in {out.resolve()}")

    if args.slack_webhook:
        try:
            req = urllib.request.Request(args.slack_webhook, data=json.dumps({"text": slack_text(a)}).encode(),
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=15)
            print("Posted summary to Slack.")
        except Exception as exc:
            print(f"warning: Slack post failed: {exc}", file=sys.stderr)

    if args.fail_above is not None and a.monthly_savings > args.fail_above:
        print(f"Savings ${a.monthly_savings:,.0f}/month exceed threshold ${args.fail_above:,.0f}.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())

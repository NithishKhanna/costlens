"""Markdown / JSON report for sharing, CI jobs and chat alerts."""

from __future__ import annotations

import json

from .narrator import money, template_summary
from .pipeline import Analysis


def to_markdown(a: Analysis, summary: str | None = None) -> str:
    k = a.kpis
    out = [
        "# CostLens report",
        f"_Data: {k.start.date()} to {k.end.date()} ({k.days_of_data} days, "
        f"{k.n_resources} resources, {k.n_teams} teams)_",
        "",
        "## Summary",
        summary or template_summary(a.context),
        "",
        "## Key numbers",
        "| Metric | Value |",
        "|---|---|",
        f"| Cost, last 30 days | {money(k.cost_30d)} |",
        f"| Change vs previous 30 days | {k.cost_growth_pct:+.1f}% |",
        f"| Cost index vs start (=100) | {k.cost_index_now:.0f} |",
        f"| Usage index vs start (=100) | {k.usage_index_now:.0f} |",
        f"| Annual run-rate | {money(k.annual_run_rate)} |",
        f"| Untagged spend | {k.untagged_share_pct:.1f}% |",
        f"| Identified savings | {money(a.monthly_savings)}/month ({money(round(a.monthly_savings) * 12)}/year) |",
        "",
        "## Findings",
    ]
    if not len(a.findings):
        out.append("No issues found.")
    for i, f in a.findings.iterrows():
        out += [
            f"### {i + 1}. {f['title']}",
            f"**{f['label']}** · severity {f['severity']} · owner {f['team']} · {f['service']} · "
            f"save ~{money(f['est_monthly_savings'])}/month ({f['confidence']} confidence)",
            "",
            f"- Evidence: {f['evidence']}",
            f"- Action: {f['recommendation']}",
            "",
        ]
    out += ["## Teams", "| Team | Cost 30d | Change | Usage change | Savings available |", "|---|---|---|---|---|"]
    for _, t in a.teams.iterrows():
        ug = "n/a" if t["usage_growth_pct"] != t["usage_growth_pct"] else f"{t['usage_growth_pct']:+.0f}%"
        out.append(f"| {t['team']} | {money(t['cost_30d'])} | {t['cost_growth_pct']:+.0f}% | {ug} | "
                   f"{money(t['savings_available'])}/month |")
    return "\n".join(out) + "\n"


def to_json(a: Analysis) -> str:
    return json.dumps(a.context, indent=2, default=str)


def slack_text(a: Analysis, top: int = 3) -> str:
    k = a.kpis
    lines = [f":mag: *CostLens daily check* ({k.end.date()})",
             f"30-day spend {money(k.cost_30d)} ({k.cost_growth_pct:+.1f}%), "
             f"cost index {k.cost_index_now:.0f} vs usage index {k.usage_index_now:.0f}.",
             f"*{money(a.monthly_savings)}/month* in fixable waste across {len(a.findings)} findings."]
    for _, f in a.findings.head(top).iterrows():
        lines.append(f"• [{f['severity']}] {f['title']} ({f['team']}) → save ~{money(f['est_monthly_savings'])}/mo")
    return "\n".join(lines)

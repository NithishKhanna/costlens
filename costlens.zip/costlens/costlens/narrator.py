"""Plain-English summaries and Q&A over the analysis.

If ANTHROPIC_API_KEY is set (and the `anthropic` package is installed) CostLens asks
Claude to write the executive summary and answer questions, grounded strictly in the
computed numbers. Without a key, or if the call fails, a deterministic template and a
keyword router answer instead, so the app always works offline.
"""

from __future__ import annotations

import json
import os
import re

import numpy as np
import pandas as pd

from .analysis import KPIs

DEFAULT_MODEL = os.getenv("COSTLENS_MODEL", "claude-sonnet-5-5")

SYSTEM_PROMPT = """You are CostLens, a FinOps analyst for a data platform team.
You are given a JSON snapshot of computed cost metrics, findings and team totals.
Rules:
- Use ONLY numbers present in the snapshot. Never invent resources, teams or figures.
- Money in US dollars, rounded (e.g. $6,450/month). Be concise and concrete.
- Name the resource, the owner team, the evidence, and the next action.
- If the snapshot cannot answer the question, say what data would be needed."""


def money(x: float) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "n/a"
    return f"${x:,.0f}"


# ---------------------------------------------------------------------------
# Context snapshot (what the LLM sees; also used by the offline answers)
# ---------------------------------------------------------------------------

def build_context(kpis: KPIs, findings: pd.DataFrame, teams: pd.DataFrame,
                  resources: pd.DataFrame, anomalies: pd.DataFrame) -> dict:
    def r(x, n=1):
        return None if x is None or (isinstance(x, float) and np.isnan(x)) else round(float(x), n)

    return {
        "period": {"start": kpis.start.date().isoformat(), "end": kpis.end.date().isoformat(),
                   "days": kpis.days_of_data},
        "kpis": {
            "cost_last_30d": r(kpis.cost_30d, 0),
            "cost_prev_30d": r(kpis.cost_prev_30d, 0),
            "cost_growth_pct_30d": r(kpis.cost_growth_pct),
            "usage_growth_pct_30d": r(kpis.usage_growth_pct),
            "cost_index_vs_start": r(kpis.cost_index_now),
            "usage_index_vs_start": r(kpis.usage_index_now),
            "annual_run_rate": r(kpis.annual_run_rate, 0),
            "untagged_share_pct": r(kpis.untagged_share_pct),
            "total_est_monthly_savings": r(findings["est_monthly_savings"].sum(), 0) if len(findings) else 0,
        },
        "findings": [
            {k: (r(v, 0) if isinstance(v, float) else v) for k, v in row.items()}
            for row in findings[["label", "severity", "resource_name", "team", "service", "environment",
                                 "monthly_cost", "est_monthly_savings", "confidence", "evidence",
                                 "recommendation"]].to_dict("records")
        ],
        "teams": [
            {"team": t["team"], "cost_30d": r(t["cost_30d"], 0), "cost_growth_pct": r(t["cost_growth_pct"]),
             "usage_growth_pct": r(t["usage_growth_pct"]), "share_pct": r(t["share_pct"]),
             "savings_available": r(t["savings_available"], 0)}
            for _, t in teams.iterrows()
        ],
        "top_resources": [
            {"resource": x["resource_name"], "team": x["team"], "service": x["service"],
             "cost_30d": r(x["cost_30d"], 0), "cost_growth_pct": r(x["cost_growth_pct"]),
             "usage_growth_pct": r(x["usage_growth_pct"])}
            for _, x in resources.head(10).iterrows()
        ],
        "anomalies": [
            {"date": a["date"].date().isoformat(), "resource": a["resource_name"], "team": a["team"],
             "cost": r(a["cost_usd"], 0), "expected": r(a["expected_usd"], 0)}
            for _, a in anomalies.head(10).iterrows()
        ],
    }


# ---------------------------------------------------------------------------
# LLM access
# ---------------------------------------------------------------------------

def llm_available(api_key: str | None = None) -> bool:
    if not (api_key or os.getenv("ANTHROPIC_API_KEY")):
        return False
    try:
        import anthropic  # noqa: F401
    except ImportError:
        return False
    return True


def _ask_llm(prompt: str, context: dict, api_key: str | None, max_tokens: int = 700) -> str:
    import anthropic

    client = anthropic.Anthropic(api_key=api_key or os.getenv("ANTHROPIC_API_KEY"), timeout=45)
    msg = client.messages.create(
        model=DEFAULT_MODEL,
        max_tokens=max_tokens,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content":
                   f"Snapshot:\n```json\n{json.dumps(context, default=str)}\n```\n\n{prompt}"}],
    )
    return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()


# ---------------------------------------------------------------------------
# Executive summary
# ---------------------------------------------------------------------------

def template_summary(ctx: dict) -> str:
    k = ctx["kpis"]
    f = ctx["findings"]
    lines = []
    ci, ui = k["cost_index_vs_start"], k["usage_index_vs_start"]
    if ci is not None and ui is not None:
        lines.append(
            f"**Since {ctx['period']['start']}, platform cost is up {ci - 100:.0f}% while usage "
            f"is {'up' if ui >= 100 else 'down'} {abs(ui - 100):.0f}%.** "
            f"Spend is {money(k['cost_last_30d'])} over the last 30 days "
            f"(annual run-rate {money(k['annual_run_rate'])})."
        )
    saving = k["total_est_monthly_savings"] or 0
    actionable = [x for x in f if (x["est_monthly_savings"] or 0) > 0]
    if actionable:
        pct = saving / k["cost_last_30d"] * 100 if k["cost_last_30d"] else 0
        lines.append(
            f"CostLens found **{len(actionable)} fixable issues worth about {money(saving)}/month "
            f"({money(saving * 12)}/year, {pct:.0f}% of spend)**. The biggest:"
        )
        for x in sorted(actionable, key=lambda z: -z["est_monthly_savings"])[:3]:
            lines.append(f"- **{x['resource_name']}** ({x['team']}): {x['label'].lower()}, "
                         f"save ~{money(x['est_monthly_savings'])}/month. {x['recommendation'].split('.')[0]}.")
    spikes = [x for x in f if x["label"] == "Cost spike"]
    if spikes:
        lines.append(f"{len(spikes)} cost spike(s) need a root-cause check, e.g. "
                     f"{spikes[0]['resource_name']} ({spikes[0]['team']}).")
    if k["untagged_share_pct"]:
        lines.append(f"{k['untagged_share_pct']:.1f}% of spend has no owner tag.")
    if not f:
        lines.append("No waste patterns detected. Cost is moving in line with usage.")
    return "\n\n".join(lines)


def executive_summary(ctx: dict, use_llm: bool = True, api_key: str | None = None) -> tuple[str, str]:
    """Returns (text, source) where source is 'claude' or 'offline'."""
    if use_llm and llm_available(api_key):
        try:
            text = _ask_llm(
                "Write a 120-180 word executive summary for the CTO and CFO: the cost-vs-usage "
                "gap, the top 3 actions with owners and dollar savings, and one risk to watch. "
                "Use markdown with bold for the key numbers.", ctx, api_key)
            if text:
                return text, "claude"
        except Exception as exc:  # network, auth, quota... fall back quietly
            return template_summary(ctx) + f"\n\n_(AI summary unavailable: {type(exc).__name__}; showing offline summary.)_", "offline"
    return template_summary(ctx), "offline"


# ---------------------------------------------------------------------------
# Q&A
# ---------------------------------------------------------------------------

def _match_team(q: str, ctx: dict) -> str | None:
    for t in ctx["teams"]:
        if t["team"].lower() in q:
            return t["team"]
    return None


def _match_resource(q: str, ctx: dict) -> list[dict]:
    hits = []
    for x in ctx["findings"]:
        name = x["resource_name"].lower()
        tokens = [w for w in re.split(r"[^a-z0-9]+", name) if len(w) >= 4]
        if name in q or any(tok in q for tok in tokens):
            hits.append(x)
    return hits


def offline_answer(question: str, ctx: dict) -> str:
    q = question.lower()
    k = ctx["kpis"]
    findings = ctx["findings"]

    hits = _match_resource(q, ctx)
    if hits:
        out = []
        for x in hits:
            out.append(f"**{x['resource_name']}** ({x['team']}, {x['service']}): {x['label'].lower()}. "
                       f"{x['evidence']} **Do this:** {x['recommendation']} "
                       f"Estimated saving: {money(x['est_monthly_savings'])}/month.")
        return "\n\n".join(out)

    team = _match_team(q, ctx)
    if team:
        t = next(t for t in ctx["teams"] if t["team"] == team)
        tf = [x for x in findings if x["team"] == team]
        msg = (f"**{team}** spent {money(t['cost_30d'])} in the last 30 days ({t['share_pct']:.0f}% of total), "
               f"cost {t['cost_growth_pct']:+.0f}% vs the previous 30 days")
        if t["usage_growth_pct"] is not None:
            msg += f", usage {t['usage_growth_pct']:+.0f}%"
        msg += "."
        if tf:
            msg += f" {len(tf)} finding(s), {money(t['savings_available'])}/month to save:\n"
            msg += "\n".join(f"- {x['resource_name']}: "
                             f"{x['label'].lower()}, ~{money(x['est_monthly_savings'])}/month"
                             for x in tf)
        else:
            msg += " No issues found for this team."
        return msg

    if any(w in q for w in ["spike", "anomal", "jump", "sudden"]):
        if not ctx["anomalies"]:
            return "No cost spikes were detected in this period."
        return "Cost spikes detected:\n" + "\n".join(
            f"- {a['date']}: {a['resource']} ({a['team']}) cost {money(a['cost'])} vs ~{money(a['expected'])} normal"
            for a in ctx["anomalies"])

    if any(w in q for w in ["tag", "owner", "unallocated", "untagged"]):
        ut = [x for x in findings if x["label"] == "No owner tag"]
        return (f"{k['untagged_share_pct']:.1f}% of spend has no team tag. "
                + (" Untagged: " + ", ".join(f"{x['resource_name']} ({money(x['monthly_cost'])}/month)" for x in ut)
                   if ut else ""))

    if any(w in q for w in ["forecast", "next quarter", "projection", "predict", "future"]):
        return (f"At today's run-rate the platform costs {money(k['annual_run_rate'])}/year. "
                f"Applying all recommendations would remove about {money((k['total_est_monthly_savings'] or 0) * 12)}/year. "
                "See the Forecast tab for the 90-day projection.")

    if any(w in q for w in ["why", "grow", "increase", "faster", "gap", "rising"]):
        drivers = sorted(ctx["top_resources"], key=lambda r: -((r["cost_growth_pct"] or 0) - (r["usage_growth_pct"] or 0)))
        reg = [x for x in findings if x["label"] in ("Cost per unit jumped", "Idle resource", "Non-prod running 24/7")]
        msg = (f"Cost is at {k['cost_index_vs_start']:.0f} vs usage at {k['usage_index_vs_start']:.0f} "
               f"(both 100 at the start). The gap comes from:\n")
        src = reg or drivers[:3]
        msg += "\n".join(f"- **{x.get('resource_name', x.get('resource'))}**: "
                         f"{x.get('evidence', '')[:200] or 'cost up %s%% vs usage %s%%' % (x['cost_growth_pct'], x['usage_growth_pct'])}"
                         for x in src[:4])
        return msg

    if any(w in q for w in ["save", "saving", "cut", "reduce", "biggest", "top", "quick win", "first"]):
        act = sorted([x for x in findings if (x["est_monthly_savings"] or 0) > 0],
                     key=lambda z: -z["est_monthly_savings"])
        if not act:
            return "No savings opportunities found."
        return (f"Total identified: **{money(k['total_est_monthly_savings'])}/month**. In order:\n" +
                "\n".join(f"{i}. **{x['resource_name']}** ({x['team']}): {x['label'].lower()}, "
                          f"~{money(x['est_monthly_savings'])}/month, {x['confidence']} confidence"
                          for i, x in enumerate(act[:6], 1)))

    if any(w in q for w in ["total", "spend", "cost", "how much"]):
        return (f"Last 30 days: {money(k['cost_last_30d'])} ({k['cost_growth_pct_30d']:+.1f}% vs previous 30 days). "
                f"Annual run-rate {money(k['annual_run_rate'])}.")

    return ("I can answer questions about savings, cost growth, spikes, owners/tags, the forecast, "
            "a team (e.g. 'What about ML?') or a resource (e.g. 'Tell me about ANALYTICS_WH'). "
            "Add an Anthropic API key in the sidebar for open-ended questions.")


def answer(question: str, ctx: dict, use_llm: bool = True, api_key: str | None = None,
           history: list[dict] | None = None) -> tuple[str, str]:
    if use_llm and llm_available(api_key):
        try:
            convo = ""
            for h in (history or [])[-6:]:
                convo += f"{h['role'].upper()}: {h['content']}\n"
            prefix = ("Conversation so far:\n" + convo) if convo else ""
            prompt = prefix + "Question: " + question + "\nAnswer in under 150 words."
            text = _ask_llm(prompt, ctx, api_key, 500)
            if text:
                return text, "claude"
        except Exception:
            pass
    return offline_answer(question, ctx), "offline"

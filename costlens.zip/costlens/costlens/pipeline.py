"""One call that runs the full analysis. Used by the web app and the CLI."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from .analysis import (KPIs, compute_kpis, cost_usage_index, detect_anomalies, forecast,
                       resource_summary, team_summary)
from .detectors import Thresholds, run_detectors
from .narrator import build_context


@dataclass
class Analysis:
    df: pd.DataFrame
    kpis: KPIs
    index: pd.DataFrame
    anomalies: pd.DataFrame
    findings: pd.DataFrame
    teams: pd.DataFrame
    resources: pd.DataFrame
    forecast: pd.DataFrame
    context: dict

    @property
    def monthly_savings(self) -> float:
        return float(self.findings["est_monthly_savings"].sum()) if len(self.findings) else 0.0


def analyse(df: pd.DataFrame, thresholds: Thresholds | None = None) -> Analysis:
    kpis = compute_kpis(df)
    anomalies = detect_anomalies(df)
    findings = run_detectors(df, thresholds, anomalies=anomalies)
    teams = team_summary(df, findings)
    resources = resource_summary(df)
    savings = float(findings["est_monthly_savings"].sum()) if len(findings) else 0.0
    fc = forecast(df, monthly_savings=savings)
    ctx = build_context(kpis, findings, teams, resources, anomalies)
    return Analysis(df=df, kpis=kpis, index=cost_usage_index(df), anomalies=anomalies,
                    findings=findings, teams=teams, resources=resources, forecast=fc, context=ctx)

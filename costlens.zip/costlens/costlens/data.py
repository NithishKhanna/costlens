"""Loading, validating and generating cost + usage data.

CostLens works on one tidy table: one row per resource per day.

Required columns
    date          ISO date (YYYY-MM-DD)
    resource_id   stable identifier of the resource
    service       e.g. "Snowflake", "AWS EC2", "Databricks"
    cost_usd      cost billed for that resource on that day

Optional columns (sensible defaults are filled in when missing)
    resource_name   human readable name               (defaults to resource_id)
    category        compute | warehouse | storage | database | saas | other
    team            owning team; blank means untagged (defaults to "Untagged")
    environment     prod | staging | dev | test       (defaults to "unknown")
    usage_units     business usage that day: queries, task runs, reads, active users...
    usage_unit_name label for usage_units
    utilization_pct average utilisation 0-100 (CPU, warehouse load, seats used...)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ["date", "resource_id", "service", "cost_usd"]
OPTIONAL_DEFAULTS = {
    "resource_name": None,  # filled from resource_id
    "category": "other",
    "team": "Untagged",
    "environment": "unknown",
    "usage_units": np.nan,
    "usage_unit_name": "units",
    "utilization_pct": np.nan,
}
VALID_CATEGORIES = {"compute", "warehouse", "storage", "database", "saas", "other"}
NON_PROD_ENVS = {"dev", "development", "staging", "test", "sandbox", "qa"}

# Common column names from cloud billing exports, mapped to CostLens names.
COLUMN_ALIASES = {
    "usage_date": "date",
    "day": "date",
    "chargeperiodstart": "date",
    "resourceid": "resource_id",
    "resource": "resource_id",
    "resourcename": "resource_name",
    "servicename": "service",
    "service_name": "service",
    "cost": "cost_usd",
    "billedcost": "cost_usd",
    "effectivecost": "cost_usd",
    "unblended_cost": "cost_usd",
    "amount": "cost_usd",
    "owner": "team",
    "tag_team": "team",
    "env": "environment",
    "usage": "usage_units",
    "utilization": "utilization_pct",
    "utilisation_pct": "utilization_pct",
}


class DataValidationError(ValueError):
    """Raised when an input file cannot be used."""


@dataclass
class LoadResult:
    df: pd.DataFrame
    warnings: list[str] = field(default_factory=list)


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    renamed = {}
    for col in df.columns:
        key = str(col).strip().lower().replace(" ", "_").replace("-", "_")
        renamed[col] = COLUMN_ALIASES.get(key.replace("_", ""), COLUMN_ALIASES.get(key, key))
    return df.rename(columns=renamed)


def prepare(df: pd.DataFrame) -> LoadResult:
    """Validate a raw dataframe and return a clean, typed copy plus warnings."""
    warnings: list[str] = []
    df = _normalise_columns(df.copy())

    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise DataValidationError(
            f"Missing required column(s): {', '.join(missing)}. "
            f"Required: {', '.join(REQUIRED_COLUMNS)}."
        )
    if df.empty:
        raise DataValidationError("The file has no rows.")

    df["date"] = pd.to_datetime(df["date"], errors="coerce", utc=True).dt.tz_localize(None)
    bad_dates = int(df["date"].isna().sum())
    if bad_dates:
        warnings.append(f"Dropped {bad_dates} row(s) with unreadable dates.")
        df = df.dropna(subset=["date"])
    df["date"] = df["date"].dt.normalize()

    df["cost_usd"] = pd.to_numeric(df["cost_usd"], errors="coerce")
    bad_cost = int(df["cost_usd"].isna().sum())
    if bad_cost:
        warnings.append(f"Treated {bad_cost} unreadable cost value(s) as 0.")
    df["cost_usd"] = df["cost_usd"].fillna(0.0)
    if (df["cost_usd"] < 0).any():
        warnings.append("Negative costs (credits/refunds) found; they are kept as-is.")

    for col, default in OPTIONAL_DEFAULTS.items():
        if col not in df.columns:
            df[col] = default
    df["resource_id"] = df["resource_id"].astype(str)
    df["resource_name"] = df["resource_name"].where(
        df["resource_name"].notna() & (df["resource_name"].astype(str).str.strip() != ""),
        df["resource_id"],
    ).astype(str)

    df["team"] = df["team"].fillna("").astype(str).str.strip()
    untagged_rows = df["team"].isin(["", "nan", "None"])
    df.loc[untagged_rows, "team"] = "Untagged"

    df["category"] = df["category"].fillna("other").astype(str).str.lower().str.strip()
    unknown_cat = ~df["category"].isin(VALID_CATEGORIES)
    if unknown_cat.any():
        warnings.append(
            f"{int(unknown_cat.sum())} row(s) had an unknown category and were set to 'other'."
        )
        df.loc[unknown_cat, "category"] = "other"

    df["environment"] = df["environment"].fillna("unknown").astype(str).str.lower().str.strip()
    df["service"] = df["service"].astype(str)
    df["usage_unit_name"] = df["usage_unit_name"].fillna("units").astype(str)
    df["usage_units"] = pd.to_numeric(df["usage_units"], errors="coerce")
    df["utilization_pct"] = pd.to_numeric(df["utilization_pct"], errors="coerce").clip(0, 100)

    # Collapse duplicates (e.g. several line items for one resource on one day).
    dupes = df.duplicated(subset=["date", "resource_id"]).sum()
    if dupes:
        warnings.append(f"Merged {int(dupes)} duplicate resource-day row(s) by summing cost.")
        meta_cols = ["resource_name", "service", "category", "team", "environment", "usage_unit_name"]
        df = (
            df.groupby(["date", "resource_id"], as_index=False)
            .agg(
                {**{c: "first" for c in meta_cols},
                 "cost_usd": "sum", "usage_units": "sum", "utilization_pct": "mean"}
            )
        )

    span = (df["date"].max() - df["date"].min()).days + 1
    if span < 60:
        warnings.append(
            f"Only {span} days of data. Trend and regression checks work best with 90+ days."
        )

    df = df.sort_values(["date", "resource_id"]).reset_index(drop=True)
    return LoadResult(df=df, warnings=warnings)


def load_csv(path_or_buffer) -> LoadResult:
    try:
        raw = pd.read_csv(path_or_buffer)
    except Exception as exc:  # pragma: no cover - depends on file contents
        raise DataValidationError(f"Could not read the CSV file: {exc}") from exc
    return prepare(raw)


# ---------------------------------------------------------------------------
# Synthetic demo data
# ---------------------------------------------------------------------------

def generate_demo_data(days: int = 180, end: date | None = None, seed: int = 42) -> pd.DataFrame:
    """Create a realistic mid-size data platform with planted cost problems.

    Planted problems (what CostLens should find):
      * ANALYTICS_WH resized M -> XL: cost x4, queries flat         (unit-cost regression)
      * gpu-ml-train-01 idle for the last 45 days                   (idle resource)
      * emr-dev-sandbox runs 24/7 but is only used on weekdays      (off-hours non-prod)
      * s3-ml-checkpoints never read                                (idle storage)
      * s3-raw-landing grows fast while reads stay flat             (cold storage)
      * vm-legacy-7f3a has no owner tag and 8% CPU                  (untagged + oversized)
      * BI tool: 120 seats paid, ~45 used                           (unused licences)
      * Marketing Databricks job runaway, 2-day spike               (cost anomaly)
    Healthy resources grow cost in line with usage, so they stay quiet.
    """
    rng = np.random.default_rng(seed)
    end = end or date.today() - timedelta(days=1)
    dates = pd.date_range(end=pd.Timestamp(end), periods=days, freq="D")
    t = np.arange(days)
    weekday = dates.weekday < 5
    rows = []

    def add(rid, name, service, category, team, env, cost, usage, unit, util):
        for i, d in enumerate(dates):
            rows.append({
                "date": d.date().isoformat(),
                "resource_id": rid,
                "resource_name": name,
                "service": service,
                "category": category,
                "team": team,
                "environment": env,
                "cost_usd": round(float(max(cost[i], 0)), 2),
                "usage_units": None if usage is None else round(float(max(usage[i], 0)), 0),
                "usage_unit_name": unit,
                "utilization_pct": None if util is None else round(float(np.clip(util[i], 0, 100)), 1),
            })

    def noise(scale, n=days):
        return rng.normal(1.0, scale, n)

    def growth(rate_per_day):
        return (1 + rate_per_day) ** t

    resize_day = days - 75

    # 1. ANALYTICS_WH: resized to XL, queries flat -> unit cost x4
    q = 9000 * growth(0.0008) * np.where(weekday, 1.0, 0.35) * noise(0.06)
    size = np.where(t >= resize_day, 4.0, 1.0)
    cost = 120 * size * np.where(weekday, 1.0, 0.45) * noise(0.05)
    util = np.where(t >= resize_day, 17, 68) * noise(0.08)
    add("wh-analytics", "ANALYTICS_WH", "Snowflake", "warehouse", "Analytics", "prod", cost, q, "queries", util)

    # 2. ETL_WH: healthy, cost tracks usage
    g = growth(0.0022)
    runs = 4200 * g * noise(0.04)
    add("wh-etl", "ETL_WH", "Snowflake", "warehouse", "Data Platform", "prod",
        210 * g * noise(0.04), runs, "queries", 72 * noise(0.05))

    # 3. BI_WH: healthy
    g = growth(0.0012)
    add("wh-bi", "BI_WH", "Snowflake", "warehouse", "Finance", "prod",
        85 * g * np.where(weekday, 1, 0.3) * noise(0.05),
        2600 * g * np.where(weekday, 1, 0.3) * noise(0.05), "queries", 61 * noise(0.06))

    # 4. Airflow on Kubernetes: healthy
    g = growth(0.0018)
    add("k8s-airflow-prod", "airflow-prod (EKS)", "AWS EKS", "compute", "Data Platform", "prod",
        160 * g * noise(0.03), 1850 * g * noise(0.03), "task runs", 64 * noise(0.05))

    # 5. Dev sandbox running 24/7, used on weekdays only
    usage = np.where(weekday, 140, 3) * noise(0.15)
    util = np.where(weekday, 46, 4) * noise(0.1)
    add("emr-dev-sandbox", "emr-dev-sandbox", "AWS EMR", "compute", "Data Platform", "dev",
        96 * noise(0.03), usage, "jobs", util)

    # 6. GPU training box: used, then idle for the last 45 days
    idle_from = days - 45
    usage = np.where(t >= idle_from, 0, 22 * noise(0.2))
    util = np.where(t >= idle_from, 1.5, 58) * noise(0.2)
    add("gpu-ml-train-01", "gpu-ml-train-01 (p4d)", "AWS EC2", "compute", "ML", "staging",
        212 * noise(0.01), usage, "training jobs", util)

    # 7. Raw landing bucket: storage grows fast, reads flat
    add("s3-raw-landing", "s3://raw-landing", "AWS S3", "storage", "Data Platform", "prod",
        38 * growth(0.0055) * noise(0.01), 52000 * noise(0.08), "read requests", None)

    # 8. Old ML checkpoints bucket: never read
    add("s3-ml-checkpoints", "s3://ml-checkpoints-2024", "AWS S3", "storage", "ML", "prod",
        31 * growth(0.0004) * noise(0.005), np.zeros(days), "read requests", None)

    # 9. Marketing Databricks job with a 2-day runaway
    g = growth(0.0015)
    cost = 70 * g * noise(0.06)
    spike = days - 24
    cost[spike] *= 8.5
    cost[spike + 1] *= 6.0
    add("dbx-marketing-jobs", "marketing-attribution job", "Databricks", "compute", "Marketing", "prod",
        cost, 30 * g * noise(0.05), "job runs", 55 * noise(0.08))

    # 10. Untagged legacy VM, nearly idle CPU but still serving a few requests
    add("vm-legacy-7f3a", "vm-legacy-7f3a", "AWS EC2", "compute", "", "prod",
        62 * noise(0.01), 400 * noise(0.2), "requests", 8 * noise(0.2))

    # 11. BI tool licences: 120 seats, ~45 active users
    seats = 120
    active = np.where(weekday, 45, 12) * noise(0.08)
    add("saas-bi-licences", "BI tool licences (120 seats)", "Looker", "saas", "Finance", "prod",
        np.full(days, seats * 60 / 30.4), active, "active users", active / seats * 100)

    # 12. Reporting database: healthy
    g = growth(0.001)
    add("rds-reporting", "reporting-db (RDS)", "AWS RDS", "database", "Finance", "prod",
        74 * g * noise(0.02), 15000 * g * noise(0.05), "queries", 49 * noise(0.06))

    # 13. Staging Kubernetes: modest, used most days
    add("k8s-staging", "staging cluster (EKS)", "AWS EKS", "compute", "Data Platform", "staging",
        48 * noise(0.03), np.where(weekday, 300, 180) * noise(0.1), "deployments", 41 * noise(0.08))

    return pd.DataFrame(rows)

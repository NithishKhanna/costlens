from datetime import date

import numpy as np
import pandas as pd
import pytest

from costlens.cli import main as cli_main
from costlens.data import DataValidationError, generate_demo_data, prepare
from costlens.detectors import Thresholds, run_detectors
from costlens.narrator import executive_summary, offline_answer
from costlens.pipeline import analyse
from costlens.report import to_markdown


@pytest.fixture(scope="module")
def demo():
    return analyse(prepare(generate_demo_data(end=date(2026, 10, 29))).df)


def kinds_for(a, name_part):
    f = a.findings
    return set(f.loc[f["resource_name"].str.contains(name_part, regex=False), "kind"])


# --- Data loading ----------------------------------------------------------

def test_missing_required_column_is_rejected():
    with pytest.raises(DataValidationError, match="cost_usd"):
        prepare(pd.DataFrame({"date": ["2026-01-01"], "resource_id": ["a"], "service": ["x"]}))


def test_focus_style_columns_are_mapped():
    raw = pd.DataFrame({
        "ChargePeriodStart": ["2026-01-01T00:00:00Z", "2026-01-02T00:00:00Z"],
        "ResourceId": ["r1", "r1"], "ServiceName": ["EC2", "EC2"], "BilledCost": [10, "oops"],
    })
    r = prepare(raw)
    assert list(r.df["cost_usd"]) == [10.0, 0.0]
    assert (r.df["team"] == "Untagged").all()
    assert any("unreadable cost" in w for w in r.warnings)


def test_duplicate_rows_are_merged():
    raw = pd.DataFrame({"date": ["2026-01-01"] * 2, "resource_id": ["r1"] * 2,
                        "service": ["S3"] * 2, "cost_usd": [1.5, 2.5]})
    r = prepare(raw)
    assert len(r.df) == 1 and r.df["cost_usd"].iloc[0] == 4.0


# --- Detectors find every planted problem ------------------------------------

def test_planted_problems_are_found(demo):
    assert "unit_cost_regression" in kinds_for(demo, "ANALYTICS_WH")
    assert "idle" in kinds_for(demo, "gpu-ml-train-01")
    assert "off_hours" in kinds_for(demo, "emr-dev-sandbox")
    assert "idle" in kinds_for(demo, "ml-checkpoints")
    assert "cold_storage" in kinds_for(demo, "raw-landing")
    assert {"untagged", "underutilized"} <= kinds_for(demo, "vm-legacy")
    assert "unused_licences" in kinds_for(demo, "BI tool")
    assert "cost_spike" in kinds_for(demo, "marketing")


def test_healthy_resources_stay_quiet(demo):
    for healthy in ["ETL_WH", "BI_WH", "airflow-prod", "reporting-db", "staging cluster"]:
        assert kinds_for(demo, healthy) == set(), healthy


def test_no_double_counting_on_idle_resource(demo):
    f = demo.findings
    gpu = f[f["resource_name"].str.contains("gpu")]
    assert list(gpu["kind"]) == ["idle"]


def test_savings_never_exceed_cost(demo):
    f = demo.findings
    assert (f["est_monthly_savings"] <= f["monthly_cost"] + 1e-6).all()
    assert (f["est_monthly_savings"] >= 0).all()


def test_level_shift_is_not_reported_as_spike(demo):
    an = demo.anomalies
    assert set(an["resource_id"]) == {"dbx-marketing-jobs"}


def test_thresholds_change_results():
    df = prepare(generate_demo_data(end=date(2026, 10, 29))).df
    strict = run_detectors(df, Thresholds(min_monthly_cost=5000))
    assert len(strict) < len(run_detectors(df))


# --- Portfolio metrics ------------------------------------------------------

def test_cost_grows_faster_than_usage(demo):
    k = demo.kpis
    assert k.cost_index_now > k.usage_index_now + 20
    assert k.days_of_data == 180
    assert 0 < k.untagged_share_pct < 10


def test_forecast_with_fixes_is_lower(demo):
    fut = demo.forecast[demo.forecast["forecast"].notna()]
    assert len(fut) == 90
    assert fut["with_fixes"].sum() < fut["forecast"].sum()


def test_flat_healthy_platform_has_no_findings():
    days = pd.date_range("2026-01-01", periods=120, freq="D")
    raw = pd.DataFrame({"date": days, "resource_id": "r1", "service": "EC2", "category": "compute",
                        "team": "A", "environment": "prod", "cost_usd": 100.0,
                        "usage_units": 1000.0, "utilization_pct": 60.0})
    a = analyse(prepare(raw).df)
    assert len(a.findings) == 0
    assert abs(a.kpis.cost_index_now - a.kpis.usage_index_now) < 1


# --- Narrative and outputs --------------------------------------------------

def test_offline_summary_mentions_savings(demo):
    text, src = executive_summary(demo.context, use_llm=False)
    assert src == "offline"
    assert "/month" in text
    assert "ANALYTICS_WH" in text and "gpu-ml-train-01" in text


@pytest.mark.parametrize("q,expect", [
    ("Where can we save the most?", "Total identified"),
    ("What about the ML team?", "ML"),
    ("Were there any cost spikes?", "marketing"),
    ("tell me about ANALYTICS_WH", "Do this"),
    ("What has no owner?", "vm-legacy"),
])
def test_offline_answers(demo, q, expect):
    assert expect.lower() in offline_answer(q, demo.context).lower()


def test_markdown_report(demo):
    md = to_markdown(demo)
    assert md.startswith("# CostLens report")
    assert "## Findings" in md and "## Teams" in md


def test_cli_demo_run(tmp_path):
    code = cli_main(["--demo", "--no-llm", "--out", str(tmp_path)])
    assert code == 0
    assert (tmp_path / "report.md").exists()
    assert len(pd.read_csv(tmp_path / "findings.csv")) >= 8
    assert cli_main(["--demo", "--no-llm", "--out", str(tmp_path), "--fail-above", "1000"]) == 2

# Deployment and run guide

CostLens is a single Python app with no database. Pick the option that fits.

| Option | Best for | Time |
|---|---|---|
| [1. Run locally](#1-run-locally) | trying it, judging, development | 2 min |
| [2. Streamlit Community Cloud](#2-streamlit-community-cloud-free-public-url) | a free public demo URL | 5 min |
| [3. Docker](#3-docker) | any server or cloud container service | 5 min |
| [4. Linux VM with systemd](#4-linux-vm-with-systemd) | an always-on internal tool | 15 min |
| [5. Nightly report job](#5-nightly-report-job) | alerts in Slack / CI without the UI | 5 min |

---

## 1. Run locally

```bash
git clone https://github.com/<your-username>/costlens.git
cd costlens
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py                 # opens http://localhost:8501
```

Check everything works:

```bash
pytest                               # 20 tests, ~2 seconds
python -m costlens.cli --demo --no-llm --out reports/
```

Optional AI narrative:

```bash
export ANTHROPIC_API_KEY=sk-ant-...  # Windows PowerShell: $env:ANTHROPIC_API_KEY="sk-ant-..."
export COSTLENS_MODEL=claude-sonnet-5-5   # optional, this is the default
```

Without a key the app runs in offline mode: summaries and chat answers come from the rule-based engine.

---

## 2. Streamlit Community Cloud (free public URL)

1. Push the repo to a **public** GitHub repository.
2. Go to https://share.streamlit.io, sign in with GitHub, click **Create app** → **Deploy a public app from GitHub**.
3. Repository: `<your-username>/costlens`, branch `main`, main file `app.py`.
4. *(Optional)* **Advanced settings → Secrets**, add:
   ```toml
   ANTHROPIC_API_KEY = "sk-ant-..."
   ```
   Streamlit exposes secrets as environment variables, so no code change is needed.
5. Click **Deploy**. Python version 3.11 or 3.12 is recommended.

Put the resulting `https://<name>.streamlit.app` link at the top of the README and in your submission.

> Note: with a key in Secrets, everyone using the public URL spends your API credit. For a public demo
> you can leave Secrets empty; the offline mode shows every feature, and judges can paste their own key
> in the sidebar.

---

## 3. Docker

```bash
docker build -t costlens .
docker run --rm -p 8501:8501 costlens
# with AI narrative:
docker run --rm -p 8501:8501 -e ANTHROPIC_API_KEY=sk-ant-... costlens
```

Open http://localhost:8501. The same image runs on Google Cloud Run, AWS App Runner, Azure Container
Apps, Render, Railway or Fly.io. Expose port **8501** and set `ANTHROPIC_API_KEY` as a secret.

Example, Google Cloud Run:

```bash
gcloud run deploy costlens --source . --port 8501 --allow-unauthenticated --region asia-south1
```

The CLI is in the same image:

```bash
docker run --rm -v "$PWD/reports:/app/reports" costlens \
  python -m costlens.cli --demo --no-llm --out reports/
```

---

## 4. Linux VM with systemd

```bash
sudo apt-get update && sudo apt-get install -y python3-venv git
sudo useradd -r -m -d /opt/costlens costlens
sudo -u costlens git clone https://github.com/<your-username>/costlens.git /opt/costlens/app
cd /opt/costlens/app
sudo -u costlens python3 -m venv .venv
sudo -u costlens .venv/bin/pip install -r requirements.txt
```

`/etc/systemd/system/costlens.service`:

```ini
[Unit]
Description=CostLens
After=network.target

[Service]
User=costlens
WorkingDirectory=/opt/costlens/app
EnvironmentFile=-/opt/costlens/app/.env
ExecStart=/opt/costlens/app/.venv/bin/streamlit run app.py --server.port 8501 --server.address 0.0.0.0
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now costlens
sudo systemctl status costlens
```

Put it behind your company SSO / reverse proxy (nginx, Caddy, an identity-aware proxy) before
exposing it: cost data is sensitive.

---

## 5. Nightly report job

The CLI is made for schedulers. It writes `report.md`, `findings.csv` and `snapshot.json`, can post a
short summary to Slack, and exits with code `2` when identified waste is above a threshold.

**cron** (every day at 07:00):

```cron
0 7 * * * cd /opt/costlens/app && .venv/bin/python -m costlens.cli \
  --input /data/exports/cost_usage_latest.csv --out /data/costlens/$(date +\%F) \
  --slack-webhook "$SLACK_WEBHOOK_URL" >> /var/log/costlens.log 2>&1
```

**Airflow** task:

```python
BashOperator(
    task_id="costlens_report",
    bash_command="python -m costlens.cli --input {{ var.value.cost_export }} --out /tmp/costlens --no-llm",
)
```

**GitHub Actions**: `.github/workflows/ci.yml` runs the tests on every push and a demo report every
night at 01:30 UTC, uploading the report as a build artifact. Add `SLACK_WEBHOOK_URL` and
`ANTHROPIC_API_KEY` repository secrets to enable Slack posts and AI summaries there.

---

## Preparing your own data

CostLens needs one CSV: **one row per resource per day**. Required: `date, resource_id, service,
cost_usd`. Add `team`, `environment`, `category`, `usage_units`, `usage_unit_name` and
`utilization_pct` for the full set of checks. Typical joins:

| Resource type | Cost from | Usage from |
|---|---|---|
| Snowflake warehouses | `WAREHOUSE_METERING_HISTORY` × credit price | `QUERY_HISTORY` count per warehouse per day |
| EC2 / EMR / EKS | AWS CUR (or FOCUS export) | CloudWatch CPU (`utilization_pct`), job or task counts |
| S3 / GCS buckets | billing export | access logs or request metrics (`read requests`) |
| Databricks | `system.billing.usage` | `system.lakeflow` job runs |
| SaaS seats | invoice / admin export | active users per day |

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Missing required column(s)` | Rename columns, or check the aliases in `costlens/data.py` (`COLUMN_ALIASES`). |
| Few or no findings | Usage and utilisation columns are missing, or under 60 days of data. Lower thresholds in **Detection settings**. |
| "Offline mode" though a key is set | Restart the app after setting the variable; check `pip show anthropic`. |
| Port 8501 busy | `streamlit run app.py --server.port 8502` |
| Large files are slow | Pre-aggregate to daily per resource; the app handles hundreds of thousands of rows. |

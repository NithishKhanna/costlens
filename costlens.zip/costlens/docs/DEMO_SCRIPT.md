# Demo video script (2 min 50 s)

**Setup before recording**
* `streamlit run app.py`, browser at 100% zoom, window ~1440×900, sidebar open.
* Optional: paste an Anthropic API key in the sidebar so the summary says "Written by Claude".
* Record with OBS, Loom, or the Windows Game Bar (Win+G) / macOS (Cmd+Shift+5). 1080p, mic close.
* Speak slowly; ~140 words a minute. The script below is ~390 words.

| Time | Screen | Say |
|---|---|---|
| **0:00 – 0:20** | Title slide from the deck (slide 1), then slide 2 | "Data platforms have a quiet problem: the bill grows much faster than the work. Flexera's 2026 State of the Cloud report puts wasted cloud spend at about 29%. Finance sees one growing line, platform teams can't say which resource caused it, and nobody owns the fix. This is CostLens." |
| **0:20 – 0:50** | App, Overview tab. Hover the KPI cards, then the red shaded area in the chart | "CostLens reads a daily cost and usage export. Here's a demo platform: 13 resources, five teams, six months. Cost is up 38%, while usage is actually down 2%. The chart shows cost against a usage index built from each resource's own work: queries, task runs, reads, active users. The red area is money that usage doesn't explain." |
| **0:50 – 1:05** | Executive summary panel | "On the right, Claude writes an executive summary for the CTO and CFO, using only the computed numbers. With no API key it falls back to an offline engine, so it always works." |
| **1:05 – 1:45** | Findings tab. Scroll through the first three cards, open "Show the data behind this" on ANALYTICS_WH | "Findings are ticket-ready: what, why, who owns it, what to do, and how much it saves. The analytics warehouse was resized in August: cost up 300%, queries up 8%, utilisation fell from 67 to 17%. Here's the data behind it. A GPU box has done zero training jobs for 45 days and still costs six thousand a month. Paid BI seats are only 41% used on busy days. A dev cluster runs all weekend for nobody." |
| **1:45 – 2:05** | Spikes tab, hover the marker; then Teams tab | "Spikes are caught with a robust baseline per resource, like this runaway Marketing job, but a permanent resize is not mistaken for a spike. Teams get showback: spend, growth, and savings available, including the untagged VM nobody owns." |
| **2:05 – 2:20** | Forecast tab | "Finance gets the next quarter: about $189k if nothing changes, $133k with the fixes, so $56k avoided." |
| **2:20 – 2:35** | Ask CostLens tab, click "What about the ML team?" | "Anyone can just ask: what about the ML team? Answers come straight from the analysis." |
| **2:35 – 2:50** | Terminal: `python -m costlens.cli --demo --out reports/`, then the closing slide | "And it runs nightly from cron, Airflow or GitHub Actions, posting to Slack. In total CostLens found $22,500 a month, $270k a year, 37% of spend, each finding with evidence. Open source, MIT licensed. Thank you." |

**Checklist before upload**
- [ ] Under 3:00 (trim pauses in the editor)
- [ ] Text readable at 1080p
- [ ] No API key visible on screen (use the password field, don't show `.env`)
- [ ] Upload as unlisted YouTube / Loom / Drive link with "anyone with the link" access
- [ ] Put the link in the README and the submission form

# Problem statement

**Track 04 · The Work Behind the Work · Platform cost growing faster than usage**

## The problem in one sentence

Data and platform teams watch their cloud and warehouse bill grow 30–50% a year while the
work the platform does barely grows, and nobody can say which resources caused the gap, who
owns them, or what to switch off.

## Who has this problem

| Who | What they experience |
|---|---|
| **Head of Data Platform / Platform Engineering** | Gets the bill at month end. Has to explain the increase to finance but has no link between cost lines and the work each resource does. |
| **Finance / FP&A** | Sees "cloud" as one fast-growing line. Cannot tell growth from waste, so budgets are cut across the board or not at all. |
| **Data, analytics and ML teams** | Spin up warehouses, clusters and GPU boxes for real needs, then never hear about them again. Nobody tells them a resource has been idle for six weeks. |
| **CTO / CFO** | Need one number: how much of the spend is buying something, and how much can be removed without hurting anyone. |

## Why it matters

* **Waste is large and normal.** Flexera's 2026 State of the Cloud Report estimates that about
  **29% of public cloud spend is wasted**, up from 27% the year before and the first rise in five
  years. For a platform spending $60k/month that is roughly $17k/month doing nothing.
* **The bill shows cost, not value.** Billing exports say *what* was charged. They do not say whether
  the warehouse ran more queries, whether anyone used the GPU box, or whether the dev cluster was
  busy at the weekend. Without usage alongside cost, every increase looks like growth.
* **Problems are found late.** A warehouse resized "for one big job" stays oversized for months. A
  runaway job is noticed on the next invoice. By then the money is gone.
* **No owner, no fix.** Untagged resources sit outside every team's budget, so nobody acts.
* **Manual reviews don't scale.** A FinOps review is a spreadsheet exercise that takes days, happens
  quarterly at best, and is out of date when it is finished.

## What success looks like

1. Every month the platform lead can see **cost growth next to usage growth**, and the gap is explained
   resource by resource.
2. Every finding comes with **evidence, an owner, a concrete action and a dollar figure**, so it can be
   assigned as a ticket the same day.
3. Spikes are caught **the day after** they happen, not on the invoice.
4. Finance gets a **forecast with and without the fixes**, so savings show up in the budget.

## Our answer: CostLens

CostLens reads a daily cost + usage table (a billing export joined with basic usage metrics) and:

* builds a **cost index vs usage index** to show how much spend usage does not explain;
* runs **seven transparent detectors**: idle resources, cost-per-unit regressions, non-prod running
  24/7, over-provisioning, cold data on hot storage, unused licences, and missing owner tags;
* flags **cost spikes** with a robust statistical baseline while ignoring permanent step-changes;
* gives **showback by team** and a **90-day forecast** with and without the fixes;
* writes an **executive summary** and answers questions in plain English using Claude, with an offline
  rule-based fallback so it works without any API key;
* runs **nightly from the command line** (cron, Airflow, GitHub Actions) and posts to Slack.

On the included demo platform (13 resources, 5 teams, 180 days) cost grew 38% while usage fell 2%.
CostLens finds **$22.5k/month ($270k/year, 37% of spend)** in fixable waste and a $1.2k runaway job,
each with the evidence behind it.
